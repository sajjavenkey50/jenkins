This directory contains a series of different examples of how to use BW Service (or Multiple Operations as it is sometimes referred to).

  soap_http:		shows how to make a standard HTTP soap service.
  soap_http2:		shows how to make a standard HTTP soap service that exposes existing Process Definitions as operation implementations. It also shows how to implement operations that throw exceptions/faults.  
  soap_jms:		shows how to make a standard JMS soap service. (You will need to configure your JMS environment to use this example).
  soap_11_12: 		two endpoints, one for SOAP 1.1 and one for SOAP 1.2.
  soap_doclit_rpclit:	two endpoints, one with doc/literal and the other with rpc/literal.
  soap_headers:		HTTP soap service using SOAP headers.
  soap_headers2:	HTTP soap service using SOAP headers. It also shows how to implement operations that throw exceptions/faults.
  soap_jms_attachments:	JMS soap service using attachments. (You will need to configure your JMS environment to use this example).
  soap_http_jms:	two endponts, one for HTTP and one for JMS. (You will need to configure your JMS environment to use this example).
  soap_https_expose_security_context:	Shows how to expose security context for a web service implemented using service resource.
  invoke_partner:	shows how to invoke services using a invoke partner activity

  service_mtom_inband: 	shows how to send large attachments to Service as in-band
  service_mtom_outofband: 	shows how to send large attachments to Service as out-of-band
