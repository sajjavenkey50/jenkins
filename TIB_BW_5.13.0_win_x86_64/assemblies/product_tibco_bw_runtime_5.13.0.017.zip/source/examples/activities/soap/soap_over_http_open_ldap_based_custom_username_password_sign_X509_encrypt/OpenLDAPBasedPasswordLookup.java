package com.tibco.spin.soap.security;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.net.URL;

import java.util.Iterator;
import java.util.Properties;

import com.novell.ldap.*;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

/**
 * This class demostrates the use of password lookup mechanism based on an OPEN
 * LDAP server. In-order to make this callback handler to work; install the
 * OpenLDAP win32 server from http://lucas.bergmans.us/hacks/openldap/download
 * or build from source from www.openldap.org; replace the sldap.conf with the
 * one shipped with this example in OpenLDAP root dir; load ldap server with user
 * data using tibco-people.ldif using following command 
 * ldapadd -x -D "cn=businessworks,dc=tibco,dc=com" -f tibco-people.ldif -w secret.
 * 
 * @author Najeeb Andrabi nandrabi@tibco.com
 */

public class OpenLDAPBasedPasswordLookup implements CallbackHandler {
    private int ldapPort;

    private int ldapVersion;

    private String ldapHost;

    private String loginDN;

    private String ldapPassword;

    private LDAPConnection lc;

    String searchBase;

    private Properties properties;

    private static final String LDAP_HOST = "LDAP_Host";

    private static final String PORT = "LDAP_Port";

    private static final String LOGIN_DN = "Login_DN";

    private static final String PASSWORD = "Password";

    private static final String LDAP_VERSION = "LDAP_Version";

    private String RELATIVE_LDAP_PROP_FILE_PATH = "/config";

    private static final String USER_ID = "uid";

    private static final String USER_PASSWORD = "userPassword";

    public OpenLDAPBasedPasswordLookup() {
        lc = new LDAPConnection();

        properties = new Properties();

        try {
            URL url = this.getClass().getProtectionDomain().getCodeSource().getLocation();
            String projectDir = url.getPath();
            projectDir = projectDir.substring(projectDir.indexOf("/") + 1);
            projectDir = projectDir.substring(0,projectDir.lastIndexOf("/"));
            projectDir = projectDir.substring(0,projectDir.lastIndexOf("/"));
            String propertiesDir = projectDir + RELATIVE_LDAP_PROP_FILE_PATH;
            properties.load(new FileInputStream(propertiesDir + "/ldap.properties"));
            ldapHost = properties.getProperty(LDAP_HOST);
            loginDN = properties.getProperty(LOGIN_DN);
            ldapPassword = properties.getProperty(PASSWORD);
            String port = properties.getProperty(PORT);
            ldapPort = Integer.parseInt(port.trim());
            String ldap_version = properties.getProperty(LDAP_VERSION);
            ldapVersion = Integer.parseInt(ldap_version.trim());
            searchBase = "ou=people,dc=tibco,dc=com";
            lc.connect(ldapHost, ldapPort);
            lc.bind(ldapVersion, loginDN, ldapPassword.getBytes("UTF8"));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (LDAPException e) {
            e.printStackTrace();
        }

    }

    public void handle(Callback[] callbacks) throws IOException,
            UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
            if (callbacks[i] instanceof WSPasswordCallback) {
                WSPasswordCallback pc = (WSPasswordCallback) callbacks[i];
                String userName = pc.getIdentifer();
                int usage = pc.getUsage();
                if (usage == WSPasswordCallback.USERNAME_TOKEN
                        || usage == WSPasswordCallback.USERNAME_TOKEN_UNKNOWN) {

                    int searchScope = LDAPConnection.SCOPE_ONE;
                    boolean attributeOnly = false;
                    String attrs[] = { LDAPConnection.ALL_USER_ATTRS };

                    LDAPSearchResults searchResults;
                    try {
                        searchResults = lc.search(searchBase, // container to
                                // search
                                searchScope, // search scope
                                "", // search filter
                                attrs, // "1.1" returns entry name only
                                attributeOnly);
                        // print out all the objects
                        while (searchResults.hasMore()) {
                            LDAPEntry nextEntry = null;
                            try {
                                nextEntry = searchResults.next();
                            } catch (LDAPException e) {
                                System.out.println("Error: " + e.toString());
                                // Exception is thrown, go for next entry
                                continue;
                            }

                            String storedUID = null;
                            String storedPassword = null;
                            LDAPAttributeSet attributes = nextEntry
                                    .getAttributeSet();
                            Iterator iter = attributes.iterator();
                            while (iter.hasNext()) {
                                LDAPAttribute attribute = (LDAPAttribute) iter
                                        .next();
                                String attributeName = attribute.getName();
                                if (attributeName.equals(USER_PASSWORD)) {
                                    storedPassword = attribute
                                            .getStringValue();
                                } else if (attributeName.equals(USER_ID)) {
                                    storedUID = attribute
                                            .getStringValue();
                                }
                            }
                            
                            if(storedUID != null && storedUID.equals(userName)){
                                pc.setPassword(storedPassword);
                            }    
                        }
                    } catch (LDAPException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
    }

    public void finalize() {
        try {
            lc.disconnect();
        } catch (LDAPException e) {
            e.printStackTrace();
        }
    }
}
