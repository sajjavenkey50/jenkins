package com.tibco.spin.soap.security;

import java.net.URL;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

/**
 * This class defines a mechanism to lookup password using CallbackHandler interface 
 * from a passwd.txt file that is very similar to /etc/passwd UNIX file having an 
 * encrypted password. If this class is referred to by the Business Works Alias library 
 * shared resource, it will be used to do set password on the WSPasswordCallback that 
 * is passed in to the handle method.
 *  
 * @author Najeeb Andrabi nandrabi@tibco.com
 */

public class FileBasedPasswordLookup implements CallbackHandler {

    private String RELATIVE_PASSWORD_FILE_PATH = "/config"; 
    public void handle(Callback[] callbacks) throws IOException,
            UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
            if (callbacks[i] instanceof WSPasswordCallback) {
                WSPasswordCallback pc = (WSPasswordCallback) callbacks[i]; 
                String userName = pc.getIdentifer();
                int usage = pc.getUsage();
                if (usage == WSPasswordCallback.USERNAME_TOKEN || usage == WSPasswordCallback.USERNAME_TOKEN_UNKNOWN) {
                    String password = lookupPassword(userName);
                    if(password != null && !password.equals("")){
                        pc.setPassword(password);
                    }
                }
            }
        }
    }
    
    private String lookupPassword(String userName){
        try {
            URL url = this.getClass().getProtectionDomain().getCodeSource().getLocation();
            String projectDir = url.getPath();
            projectDir = projectDir.substring(projectDir.indexOf("/") + 1);
            projectDir = projectDir.substring(0,projectDir.lastIndexOf("/"));
            projectDir = projectDir.substring(0,projectDir.lastIndexOf("/"));
            String customPasswordFilePath = projectDir + RELATIVE_PASSWORD_FILE_PATH; 
            BufferedReader in = new BufferedReader(new FileReader(customPasswordFilePath + File.separator + "passwd.txt"));
            String str;
            while ((str = in.readLine()) != null) {
                 if(str.indexOf(":") != -1){
                     String storedUserName = str.substring(0,str.indexOf(":"));
                     if(userName.equals(storedUserName)){
                         String encryptedPassword = str.substring(str.indexOf(":") + 1);
                         encryptedPassword = encryptedPassword.substring(0,encryptedPassword.indexOf(":"));
                         return decryptPassword(encryptedPassword);
                     }
                 }
            }
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    private String decryptPassword(String encryptedPassword){
        //write decryption code here.
        String password = encryptedPassword;
        return password; 
    }
}
