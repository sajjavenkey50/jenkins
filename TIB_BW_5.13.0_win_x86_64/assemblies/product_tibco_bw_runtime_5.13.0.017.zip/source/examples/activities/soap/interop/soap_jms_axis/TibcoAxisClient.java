import org.apache.axis.AxisFault;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.configuration.XMLStringProvider;
import org.apache.axis.deployment.wsdd.WSDDConstants;
import org.apache.axis.encoding.XMLType;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.transport.jms.JMSConstants;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import java.util.HashMap;
import java.util.Map;

/**
 * Sample AXIS client progam to invoke SOAP/JMS service running in 
 * TIBCO BusinessWorks environment.
 */
public class TibcoAxisClient {

    static final String wsdd =
            "<deployment xmlns=\"http://xml.apache.org/axis/wsdd/\" " +
                  "xmlns:java=\"" + WSDDConstants.URI_WSDD_JAVA + "\">\n" +
            " <transport name=\"JMSTransport\" pivot=\"java:org.apache.axis.transport.jms.JMSSender\"/>\n" +
            " <service name=\"" + WSDDConstants.URI_WSDD + "\" provider=\"java:MSG\">\n" +
            "  <parameter name=\"allowedMethods\" value=\"AdminService\"/>\n" +
            "  <parameter name=\"className\" value=\"org.apache.axis.utils.Admin\"/>\n" +
            " </service>\n" +
            "</deployment>";

    // the JMS URL target endpoint address
    static String sampleJmsUrl = "jms:/queue.sample?" +
                                 "vendor=JNDI" +
                                 "&java.naming.factory.initial=com.tibco.tibjms.naming.TibjmsInitialContextFactory" +
                                 "&java.naming.provider.url=tibjmsnaming://localhost:7222" +
                                 "&ConnectionFactoryJNDIName=QueueConnectionFactory" +
                                 "&deliveryMode=persistent" +
                                 "&priority=5" +
                                 "&ttl=10000" +
                                 "&debug=true";

    public static void main(String args[]) throws Exception {
        AddrType res = (AddrType)getTAddress("foo");
        System.out.println("Result="+res);        
        System.exit(1);
    }

    public static class AddrType {
        public String name;
        public String city;
        public String state;
        public String zip;

        public String toString() {
            return "name="+name+" city="+city+" state="+state+" zip="+zip;
        }
    }

    public static Object getTAddress(String param) throws javax.xml.rpc.ServiceException, AxisFault {

        Service  service = new Service(new XMLStringProvider(wsdd));
        Object res = null;
        // create a new Call object
        Call     call    = (Call) service.createCall();
        call.setOperationName( new QName("http://xmlns.example.com/1095876750660/GetTAddressImpl", "GetTAddress") );
        call.addParameter( "city", XMLType.XSD_STRING, ParameterMode.IN );
        QName addr_type = new QName("http://xmlns.example.com/unique/default/namespace/1095876658698","address_type");
        call.setReturnType( addr_type );

        try
        {
            java.net.URL jmsurl = new java.net.URL(sampleJmsUrl);
            call.setTargetEndpointAddress(jmsurl);
            call.setProperty(JMSConstants.JMS_APPLICATION_MSG_PROPS, getTibcoExtensions());
            // set additional params on the call if desired
            call.setTimeout(new Integer(30000));
            call.registerTypeMapping( AddrType.class, addr_type, BeanSerializerFactory.class, BeanDeserializerFactory.class );
            res = call.invoke(new Object[] {param});
        }
        catch (java.net.MalformedURLException e) {
            throw new AxisFault("Invalid JMS URL", e);
        }
        catch (java.rmi.RemoteException e) {
            throw new AxisFault("Failed in GetTAddressImpl()", e);
        }

        return res;
    }

    private static Map getTibcoExtensions() {
        HashMap appProps = new HashMap();
        appProps.put( "SoapAction", "/Services/GetTAddress");
        appProps.put( "Content_Type", "application/xml; charset=utf-8");
        appProps.put( "Mime_Version", "1.0");
        return appProps;
    }

}
