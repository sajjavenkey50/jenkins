
package photocatalog;  

import com.example.photo.*;
import java.io.*;
import com.sun.xml.rpc.client.StubBase;
import javax.xml.rpc.ServiceFactory;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.transform.stream.StreamSource;
import java.util.*;
import com.sun.xml.rpc.client.StubPropertyConstants;
import javax.activation.DataHandler; 


public class PhotoCatalogClient {
    PhotoCatalog_PortType_Stub stub = null;      

public static void main(String[] args) {    
    try 
    {   
        PhotoCatalogClient pcClient = new PhotoCatalogClient();
        pcClient.stub = (PhotoCatalog_PortType_Stub) (new  PhotoCatalog_Service_Impl().getSOAPEventSource());   
        pcClient.invokeReplacePhoto();        
     } catch (Exception ex) {        
        ex.printStackTrace();       
     }       
   }

   
public void invokeReplacePhoto()throws Exception {
	//Fill the attachment data with the new image to be replaced
	
	//Use the BWMessageHandler.java to setup the image sent to BW

	//Send the data to BW and get the replaced photo
	String imageName = "tibco.jpg";
	java.net.URI inVal = new java.net.URI("cid:" + imageName);
	java.net.URI oldPhotoRef = stub.replacePhoto(inVal);

	//Use the BWMessageHandler.java to get the image returned by BW

} 

}
