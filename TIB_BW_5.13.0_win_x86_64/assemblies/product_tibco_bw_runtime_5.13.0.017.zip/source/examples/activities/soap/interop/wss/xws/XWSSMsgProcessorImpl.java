
import com.sun.xml.wss.impl.configuration.DeclarativeSecurityConfiguration;
import com.sun.xml.wss.impl.configuration.SecurityConfigurationXmlReader;
import com.sun.xml.wss.impl.configuration.MessagePolicy;
import com.sun.xml.wss.impl.misc.DefaultSecurityEnvironmentImpl;
import com.sun.xml.wss.*;

import javax.security.auth.callback.CallbackHandler;
import javax.xml.soap.SOAPMessage;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: rduntulu
 * Date: Dec 19, 2005
 * Time: 11:09:56 AM
 * To change this template use Options | File Templates.
 */
public class XWSSMsgProcessorImpl  implements XWSSMsgProcessor {

    private DeclarativeSecurityConfiguration declSecConfig = null;
    private CallbackHandler handler = null;
    private SecurityEnvironment secEnv = null;

    protected XWSSMsgProcessorImpl(
        InputStream securityConfig, CallbackHandler handler)
        throws XWSSecurityException {
        try {
            declSecConfig =
                SecurityConfigurationXmlReader.createDeclarativeConfiguration(securityConfig);
            this.handler = handler;
            secEnv = new DefaultSecurityEnvironmentImpl(handler);
        }catch (Exception e) {
            // log
            throw new XWSSecurityException(e);
        }
    }


    protected XWSSMsgProcessorImpl(
        InputStream securityConfig) throws XWSSecurityException {
        throw new UnsupportedOperationException("Operation Not Supported");
    }

    public SOAPMessage secureOutboundMessage(
        ProcessingContext context)
        throws XWSSecurityException {

        MessagePolicy resolvedPolicy = null;

        if (declSecConfig != null) {
            resolvedPolicy = declSecConfig.senderSettings();
        } else {
            throw new XWSSecurityException("Security Policy Unknown");
        }

        if (resolvedPolicy == null) {
            // no outbound security specified ?
            return context.getSOAPMessage();
        }
        context.setSecurityEnvironment(secEnv);
        context.setSecurityPolicy(resolvedPolicy);

        try {
            SecurityAnnotator.secureMessage(context);
        } catch (Exception e) {
            throw new XWSSecurityException(e);
        }

        try {
            SOAPMessage msg = context.getSOAPMessage();
            return msg;
        } catch (Exception e) {
            throw new XWSSecurityException(e);
        }

    }

    public SOAPMessage verifyInboundMessage(
        ProcessingContext context)
        throws XWSSecurityException {

        MessagePolicy resolvedPolicy = null;

        if (declSecConfig != null) {
            resolvedPolicy = declSecConfig.receiverSettings();
        } else {
            throw new XWSSecurityException("Security Policy Unknown");
        }

        context.setSecurityEnvironment(secEnv);
        context.setSecurityPolicy(resolvedPolicy);
        try {
            SecurityRecipient.validateMessage(context);
        } catch (Exception e) {
            throw new XWSSecurityException(e);
        }

        try {
            SOAPMessage msg = context.getSOAPMessage();
            return msg;
        } catch (Exception e) {
            throw new XWSSecurityException(e);
        }

    }
}

