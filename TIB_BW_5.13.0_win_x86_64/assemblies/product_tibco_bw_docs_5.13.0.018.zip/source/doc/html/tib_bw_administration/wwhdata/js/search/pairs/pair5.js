function FileData_Pairs(x)
{
x.t("during","release");
x.t("guide","during");
x.t("guide","changes");
x.t("guide","tibco");
x.t("preface","changes");
x.t("software","preface");
x.t("changes","guide");
x.t("changes","previous");
x.t("release","guide");
x.t("release","tibco");
x.t("previous","release");
x.t("tibco","software");
}
