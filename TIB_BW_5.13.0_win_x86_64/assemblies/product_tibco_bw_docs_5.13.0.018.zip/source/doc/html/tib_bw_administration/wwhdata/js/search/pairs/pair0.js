function FileData_Pairs(x)
{
x.t("august","2015");
x.t("5.13","august");
x.t("software","release");
x.t("software","tibco");
x.t("2015","tibco");
x.t("release","5.13");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("activematrix","businessworks");
x.t("administration","software");
x.t("businessworks","tibco");
x.t("businessworks","administration");
}
